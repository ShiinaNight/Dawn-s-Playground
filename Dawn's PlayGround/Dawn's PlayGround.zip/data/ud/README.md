Universal Damage - 通用伤害系统
作者：TheOne